    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white"><?php echo date('Y', strtotime("now")); ?> &copy; IGIPESS, Developed by <a href="https://rajneesh2350.github.io/portfolio/" target="_blank" title="Rajneesh Talwar Profile">Rajneesh Talwar</a></p>
      </div>
      <!-- /.container -->
    </footer>